<?php

include_once('AutoLoader.php');
// Register the directory to your include files
AutoLoader::registerDirectory('../include');



?>
